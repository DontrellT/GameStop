import java.util.Scanner;
public class QuizWithExceptionHandling {
   public static void main(String[] args) {
    String[] questions = {
      "What is the capital of France?\nA) Paris\nB) London\nC) Berlin",
      "Which planet is known as the Red Planet?\nA) Mars\nB) Venus\nC) Jupiter",       };
        String[] answers = {"A", "A", /* Add correct answers for other questions */};
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to the Quiz!");
        for (int i = 0; i < questions.length; i++) {
            boolean validInput = false;
            do {
            try {
            System.out.println("\nQuestion " + (i + 1) + ":");
            System.out.println(questions[i]);
            System.out.print("Your answer (A, B, or C): ");
                    String userAnswer = scanner.nextLine().toUpperCase();
                    
               if (userAnswer.isEmpty()) {
                    	throw new Exception("Empty input. Please enter A, B, or C.");
               }

               if (!userAnswer.equals("A") && !userAnswer.equals("B") && !userAnswer.equals("C")) {
                       throw new Exception("Invalid input. Please enter A, B, or C.");
               }
               if (userAnswer.equals(answers[i])) {
                        System.out.println("Correct!");
                    } else {
                        System.out.println("Incorrect. The correct answer is " + answers[i]);
                    }

                    validInput = true;

                } catch (Exception e) {
                    System.out.println("Error: " + e.getMessage());
                }
            } while (!validInput);
        }
        scanner.close();
    }
}